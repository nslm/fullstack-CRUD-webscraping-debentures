import React from "react";
import { Table, TableHead, TableBody, TableRow, TableCell, TablePagination } from "@mui/material";
import { LogEntry, LOG_COLUMNS } from "../constants/AutomationsConstants";

type Props = {
  id: string;
  logs: LogEntry[];
  page: number;
  rowsPerPage: number;
  onChangePage: (id: string, e: unknown, page: number) => void;
  onChangeRowsPerPage: (id: string, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
};

const AutomationsLogsTable: React.FC<Props> = ({ id, logs, page, rowsPerPage, onChangePage, onChangeRowsPerPage }) => {
  const columns = LOG_COLUMNS[id] ?? [{ field: "data_exec", label: "Horário Execução" }, { field: "status_final", label: "Status" }];

  const emptyRows = page > 0
    ? Math.max(0, (1 + page) * rowsPerPage - logs.length)
    : Math.max(0, rowsPerPage - Math.min(logs.length, rowsPerPage));

  const paginatedLogs = logs.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <>
      <Table size="small" stickyHeader>
        <TableHead>
          <TableRow>
            {columns.map(col => (
              <TableCell key={col.field}>{col.label}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {paginatedLogs.map((log, index) => (
            <TableRow key={index}>
              {columns.map(col => (
                <TableCell key={col.field}>{log[col.field] ?? "-"}</TableCell>
              ))}
            </TableRow>
          ))}
          {emptyRows > 0 && Array.from({ length: emptyRows }).map((_, i) => (
            <TableRow key={`empty-${i}`} style={{ height: 33 }}>
              <TableCell colSpan={columns.length} />
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={logs.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={(e, newPage) => onChangePage(id, e, newPage)}
        onRowsPerPageChange={(e) => onChangeRowsPerPage(id, e)}
      />
    </>
  );
};

export default AutomationsLogsTable;
