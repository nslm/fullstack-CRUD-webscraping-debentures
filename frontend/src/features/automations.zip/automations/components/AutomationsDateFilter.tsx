import React from "react";
import { Box, Grid, Typography, CircularProgress } from "@mui/material";
import { DayPicker } from "react-day-picker";
import { parseISO, format, isAfter } from "date-fns";

type Props = {
  dateFilter: { startDate: string; finalDate: string };
  setDateFilter: React.Dispatch<React.SetStateAction<{ startDate: string; finalDate: string }>>;
  lastWorkday: string;
  markedDates: string[];
  notWorkdayList: string[];
  dateFilterLoading: boolean;
};

const AutomationsDateFilter: React.FC<Props> = ({ dateFilter, setDateFilter, lastWorkday, markedDates, notWorkdayList, dateFilterLoading }) => {

  if (dateFilterLoading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  const commonModifiersStart = {
      marked: markedDates.map(parseISO as (arg: string) => Date),
      startSelected: parseISO(dateFilter.startDate),
      notWorkdayPassed: notWorkdayList.map(parseISO as (arg: string) => Date),
      lastWorkday: parseISO(lastWorkday),
      pastWorkdays: (date: Date) => {
      const lw = parseISO(lastWorkday);
      const dISO = format(date, 'yyyy-MM-dd');
      if (isAfter(date, lw)) return false;
      if (markedDates.includes(dISO)) return false;
      if (notWorkdayList.includes(dISO)) return false;
      return true;
    },
    disabledFromLastWorkdayOnwards: (date: Date) => {
      const lw = parseISO(lastWorkday);
      return isAfter(date, lw);
    }
  };

  const commonModifiersFinal = {
      marked: markedDates.map(parseISO as (arg: string) => Date),
      startSelected: parseISO(dateFilter.finalDate),
      notWorkdayPassed: notWorkdayList.map(parseISO as (arg: string) => Date),
      lastWorkday: parseISO(lastWorkday),
      pastWorkdays: (date: Date) => {
      const lw = parseISO(lastWorkday);
      const dISO = format(date, 'yyyy-MM-dd');
      if (isAfter(date, lw)) return false;
      if (markedDates.includes(dISO)) return false;
      if (notWorkdayList.includes(dISO)) return false;
      return true;
    },
    disabledFromLastWorkdayOnwards: (date: Date) => {
      const lw = parseISO(lastWorkday);
      return isAfter(date, lw);
    }
  };

  const commonModifiersClassNames = {
    marked: 'marked-day',
    startSelected: 'start-selected-day',
    notWorkdayPassed: 'notworkday-day',
    lastWorkday: 'lastworkday-day',
    pastWorkdays: 'past-workday-day'
  };

  const commonModifiersStyles = {
    marked: { backgroundColor: '#1e8d22ff', color: 'white' },
    startSelected: { backgroundColor: '#0c08f7ff', color: 'white' },
    notWorkdayPassed: { backgroundColor: '#f4f5f8ff', color: 'black' },
    pastWorkdays: { backgroundColor: '#e7e6e7ff', color: 'black' }
  };

  const parseDate = (iso?: string | null) => {
    if (!iso) return undefined;
    try {
      return parseISO(iso);
    } catch {
      return undefined;
    }
  };

  return (
    <Grid container spacing={2} justifyContent="space-between" sx={{ px: 1 }}>
      <Grid item>
        <Typography fontWeight="bold">Data Início {dateFilter.startDate}</Typography>
        <DayPicker
          mode="single"
          selected={parseDate(dateFilter.startDate)}
          onSelect={(date) => { 
                     if (date) setDateFilter(
                       prev => ({ ...prev, startDate: format(date, 'yyyy-MM-dd') })); 
                     }}
          modifiers={commonModifiersStart}
          modifiersClassNames={commonModifiersClassNames}
          disabled={(date) => {
                     const lw = parseISO(lastWorkday);
                       return isAfter(date, lw);
                     }}
          modifiersStyles={commonModifiersStyles}
        />
      </Grid>
      <Grid item>
        <Typography fontWeight="bold">Data Fim {dateFilter.finalDate}</Typography>
        <DayPicker
          mode="single"
          selected={parseDate(dateFilter.finalDate)}
          onSelect={(date) => { 
                     if (date) setDateFilter(
                       prev => ({ ...prev, finalDate: format(date, 'yyyy-MM-dd') })); 
                     }}
          modifiers={commonModifiersFinal}
          modifiersClassNames={commonModifiersClassNames}
          disabled={(date) => {
                     const lw = parseISO(lastWorkday);
                       return isAfter(date, lw);
                     }}
          modifiersStyles={commonModifiersStyles}
        />
      </Grid>
    </Grid>
  );
};

export default AutomationsDateFilter;
