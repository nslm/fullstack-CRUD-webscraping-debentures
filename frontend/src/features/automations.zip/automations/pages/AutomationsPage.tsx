import { Box, Typography, Grid, Button, CircularProgress, Paper, Collapse } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";

import { AUTOMATIONS } from "../constants/AutomationsConstants";
import { useAutomationsState } from "../hooks/AutomationsHooks";
import AutomationsLogsTable from "../components/AutomationsLogsTable";
import AutomationsDateFilter from "../components/AutomationsDateFilter";

export default function AutomationsPage() {
  const {
    statuses,
    loading,
    openLogs,
    page,
    rowsPerPage,
    openDateFilter,
    dateFilter,
    lastWorkday,
    markedDates,
    notWorkdayList,
    logs,
    dateFilterLoading,
    toggleLogs,
    toggleDateFilter,
    startAutomation,
    handleChangePage,
    handleChangeRowsPerPage
  } = useAutomationsState();

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', mb: 2, px: 12, mt: 8 }}>
      <Typography variant="h4" gutterBottom>Controle de Automações</Typography>

      <Grid container spacing={8}>
        {AUTOMATIONS.map(({ id, label }) => {
          return (
            <Grid item xs={12} md={6} key={id}>
              <Paper sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: "space-between", alignItems: "center", mb: 4 }}>
                  <Typography variant="h6">{label}</Typography>
                  <Button
                    variant="contained"
                    onClick={() => startAutomation(id)}
                    disabled={!!loading[id]}
                    sx={{ backgroundColor: '#061569ff' }}
                  >
                    {loading[id] ? <CircularProgress size={24} color="inherit" /> : "Start"}
                  </Button>
                </Box>

                <Typography sx={{ mb: 2 }}>
                  {statuses[id] ?? "\u00A0"}
                </Typography>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                  <Button
                    variant="outlined"
                    onClick={() => toggleLogs(id)}
                    endIcon={openLogs[id] ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                  >
                    Logs de Execução
                  </Button>
                  {id === "balcao" && (
                    <Button
                      variant="outlined"
                      onClick={toggleDateFilter}
                      endIcon={openDateFilter ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                    >
                      Selecionar Datas
                    </Button>
                  )}
                </Box>

                <Collapse in={openLogs[id]} timeout="auto" unmountOnExit>
                  <Box sx={{ overflowX: "auto", mt: 1 }}>
                    <AutomationsLogsTable
                      id={id}
                      logs={logs[id] ?? []}
                      page={page[id] || 0}
                      rowsPerPage={rowsPerPage[id] || 5}
                      onChangePage={handleChangePage}
                      onChangeRowsPerPage={handleChangeRowsPerPage}
                    />
                  </Box>
                </Collapse>

                {id === "balcao" && (
                  <Collapse in={openDateFilter} timeout="auto" unmountOnExit>
                    <AutomationsDateFilter
                      dateFilter={dateFilter}
                      setDateFilter={() => {} /* passar setDateFilter do hook */}
                      lastWorkday={lastWorkday}
                      markedDates={markedDates}
                      notWorkdayList={notWorkdayList}
                      dateFilterLoading={dateFilterLoading}
                    />
                  </Collapse>
                )}
              </Paper>
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
}
